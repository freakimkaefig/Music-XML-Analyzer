/** @constructor */
var MusicXMLAnalyzer = {
	/**
	 * Initial starting point for Javascript Component
	 * @function
	 * @public
	 */
	init: function() {
		MusicXMLAnalyzer.ApplicationController().init();
	}
};
