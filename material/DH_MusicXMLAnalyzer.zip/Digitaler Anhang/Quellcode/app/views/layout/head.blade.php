<title>Music XML Analyzer</title>

{{ HTML::style('libs/bootstrap-3.3.2/dist/css/bootstrap.min.css'); }}
{{ HTML::style('libs/bootstrap-material-design/dist/css/material-wfont.min.css'); }}
{{ HTML::style('libs/bootstrap-material-design/dist/css/ripples.min.css'); }}
{{ HTML::style('libs/dropzone-4.0.0/dist/min/dropzone.min.css'); }}
{{ HTML::style('css/styles.css'); }}
{{ HTML::style('css/responsive.css'); }}

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">