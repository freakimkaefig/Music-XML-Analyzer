
@extends('layout.main')

@section('content')

<div class="row">
	<div class="col-xs-12">
		<h1>Searching...</h1>
	</div>
</div>

@stop